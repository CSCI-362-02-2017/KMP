#!/bin/sh

set -ex

mkdir -p /srv/src/enketo_express
ln -sf /app /srv/src/enketo_express

cd /app

npm install

/app/node_modules/.bin/grunt develop
