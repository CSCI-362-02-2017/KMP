Logs
=====

Use logrotate to rotate these files. See sample config in /setup/config/logrotate.conf
