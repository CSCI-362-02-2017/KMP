#!/bin/sh

docker exec -it enketo sh -c 'cd /app && /app/node_modules/.bin/grunt test'
