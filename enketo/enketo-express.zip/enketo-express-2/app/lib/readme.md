Client-side enketo-core library is here and symlinked to /public with grunt because a future version of this app may very well do server-side form parsing too.
