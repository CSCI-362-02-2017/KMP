## CHANGES MADE TO FONT-AWESOME FOR ENKETO

2. removed non-woff fonts in _path.scss
3. did not include non-woff fonts in /public/fonts
