(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

var settings = require( './module/settings' );

if ( settings.offline && settings.enketoId && settings.submissionParameter && settings.submissionParameter.value ) {
    location.href = window.location.pathname + window.location.hash;
}

},{"./module/settings":2}],2:[function(require,module,exports){
'use strict';

var config = require('./../../../temp-client-config.json');
var queryParams = _getAllQueryParams();
var settings = {};
var DEFAULT_MAX_SIZE = 5 * 1024 * 1024;
var DEFAULT_LOGIN_URL = '/login';
var DEFAULT_THANKS_URL = '/thanks';
var settingsMap = [ {
    q: 'return',
    s: 'returnUrl'
}, {
    q: 'returnURL',
    s: 'returnUrl'
}, {
    q: 'returnUrl',
    s: 'returnUrl'
}, {
    q: 'touch',
    s: 'touch'
}, {
    q: 'server',
    s: 'serverUrl'
}, {
    q: 'serverURL',
    s: 'serverUrl'
}, {
    q: 'serverUrl',
    s: 'serverUrl'
}, {
    q: 'form',
    s: 'xformUrl'
}, {
    q: 'id',
    s: 'xformId'
}, {
    q: 'instanceId',
    s: 'instanceId'
}, {
    q: 'instance_id',
    s: 'instanceId'
}, {
    q: 'parentWindowOrigin',
    s: 'parentWindowOrigin'
} ];

// rename query string parameters to settings, but only if they do not exist already
settingsMap.forEach( function( obj ) {
    if ( typeof queryParams[ obj.q ] !== 'undefined' && typeof settings[ obj.s ] === 'undefined' ) {
        settings[ obj.s ] = queryParams[ obj.q ];
    }
} );

//add default login Url
settings.loginUrl = config[ 'basePath' ] + DEFAULT_LOGIN_URL;

// add default return Url
settings.defaultReturnUrl = config[ 'basePath' ] + DEFAULT_THANKS_URL;

// add defaults object
settings.defaults = {};
for ( var p in queryParams ) {
    if ( queryParams.hasOwnProperty( p ) ) {
        var path;
        var value;
        if ( p.search( /d\[(.*)\]/ ) !== -1 ) {
            path = decodeURIComponent( p.match( /d\[(.*)\]/ )[ 1 ] );
            value = decodeURIComponent( queryParams[ p ] );
            settings.defaults[ path ] = value;
        }
    }
}

// add common app configuration constants
for ( var prop in config ) {
    if ( config.hasOwnProperty( prop ) ) {
        settings[ prop ] = config[ prop ];
    }
}

// add submission parameter value
if ( settings.submissionParameter && settings.submissionParameter.name ) {
    // sets to undefined when necessary
    settings.submissionParameter.value = queryParams[ settings.submissionParameter.name ];
}

// set default maxSubmissionSize
settings.maxSize = DEFAULT_MAX_SIZE;

// add type
if ( window.location.pathname.indexOf( '/preview' ) === 0 ) {
    settings.type = 'preview';
} else if ( window.location.pathname.indexOf( '/single' ) === 0 ) {
    settings.type = 'single';
} else if ( window.location.pathname.indexOf( '/edit' ) === 0 ) {
    settings.type = 'edit';
} else if ( window.location.pathname.indexOf( '/view' ) === 0 ) {
    settings.type = 'view';
} else {
    settings.type = 'other';
}

// Provide easy way to change online-only prefix if we wanted to in the future
settings.enketoIdPrefix = '::';

// Determine whether view is offline-capable
settings.offline = !!document.querySelector( 'html' ).getAttribute( 'manifest' );

// Extract Enketo ID
settings.enketoId = ( settings.offline ) ? _getEnketoId( '#', window.location.hash ) : _getEnketoId( '\/' + settings.enketoIdPrefix, window.location.pathname );

// Set multipleAllowed for single webform views
if ( settings.type === 'single' && settings.enketoId.length !== 32 && settings.enketoId.length !== 64 ) {
    settings.multipleAllowed = true;
}

// Determine whether "go to" functionality should be enabled.
settings.goTo = settings.type === 'edit' || settings.type === 'preview' || settings.type === 'view';

// A bit crude and hackable by users, but this way also type=view with a record will be caught.
settings.printRelevantOnly = !!settings.instanceId;

function _getEnketoId( prefix, haystack ) {
    var id = new RegExp( prefix ).test( haystack ) ? haystack.substring( haystack.lastIndexOf( prefix ) + prefix.length ) : null;
    return id;
}

function _getAllQueryParams() {
    var val;
    var processedVal;
    var query = window.location.search.substring( 1 );
    var vars = query.split( '&' );
    var params = {};

    for ( var i = 0; i < vars.length; i++ ) {
        var pair = vars[ i ].split( '=' );
        if ( pair[ 0 ].length > 0 ) {
            val = decodeURIComponent( pair[ 1 ] );
            processedVal = ( val === 'true' ) ? true : ( val === 'false' ) ? false : val;
            params[ pair[ 0 ] ] = processedVal;
        }
    }

    return params;
}

module.exports = settings;

},{"./../../../temp-client-config.json":3}],3:[function(require,module,exports){
module.exports={"googleApiKey":"","maps":[{"name":"streets","tiles":["https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"],"attribution":"© <a href=\"http://openstreetmap.org\">OpenStreetMap</a> | <a href=\"www.openstreetmap.org/copyright\">Terms</a>"}],"modernBrowsersURL":"modern-browsers","supportEmail":"support@kobotoolbox.org","themesSupported":["formhub","grid","kobo","plain"],"languagesSupported":["ar","cs","de","el","en","es","fa","fi","fr","hi","it","lo","nl","no","ro","sk","sv","sw","vi","zh"],"timeout":300000,"submissionParameter":{"name":""},"basePath":"","repeatOrdinals":false,"validateContinuously":false,"validatePage":true}
},{}]},{},[1])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJwdWJsaWMvanMvc3JjL21haW4tb2ZmbGluZS1mYWxsYmFjay5qcyIsInB1YmxpYy9qcy9zcmMvbW9kdWxlL3NldHRpbmdzLmpzIiwicHVibGljL3RlbXAtY2xpZW50LWNvbmZpZy5qc29uIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuSkEiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dmFyIGY9bmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKTt0aHJvdyBmLmNvZGU9XCJNT0RVTEVfTk9UX0ZPVU5EXCIsZn12YXIgbD1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwobC5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxsLGwuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgc2V0dGluZ3MgPSByZXF1aXJlKCAnLi9tb2R1bGUvc2V0dGluZ3MnICk7XG5cbmlmICggc2V0dGluZ3Mub2ZmbGluZSAmJiBzZXR0aW5ncy5lbmtldG9JZCAmJiBzZXR0aW5ncy5zdWJtaXNzaW9uUGFyYW1ldGVyICYmIHNldHRpbmdzLnN1Ym1pc3Npb25QYXJhbWV0ZXIudmFsdWUgKSB7XG4gICAgbG9jYXRpb24uaHJlZiA9IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSArIHdpbmRvdy5sb2NhdGlvbi5oYXNoO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG52YXIgY29uZmlnID0gcmVxdWlyZSgnLi8uLi8uLi8uLi90ZW1wLWNsaWVudC1jb25maWcuanNvbicpO1xudmFyIHF1ZXJ5UGFyYW1zID0gX2dldEFsbFF1ZXJ5UGFyYW1zKCk7XG52YXIgc2V0dGluZ3MgPSB7fTtcbnZhciBERUZBVUxUX01BWF9TSVpFID0gNSAqIDEwMjQgKiAxMDI0O1xudmFyIERFRkFVTFRfTE9HSU5fVVJMID0gJy9sb2dpbic7XG52YXIgREVGQVVMVF9USEFOS1NfVVJMID0gJy90aGFua3MnO1xudmFyIHNldHRpbmdzTWFwID0gWyB7XG4gICAgcTogJ3JldHVybicsXG4gICAgczogJ3JldHVyblVybCdcbn0sIHtcbiAgICBxOiAncmV0dXJuVVJMJyxcbiAgICBzOiAncmV0dXJuVXJsJ1xufSwge1xuICAgIHE6ICdyZXR1cm5VcmwnLFxuICAgIHM6ICdyZXR1cm5VcmwnXG59LCB7XG4gICAgcTogJ3RvdWNoJyxcbiAgICBzOiAndG91Y2gnXG59LCB7XG4gICAgcTogJ3NlcnZlcicsXG4gICAgczogJ3NlcnZlclVybCdcbn0sIHtcbiAgICBxOiAnc2VydmVyVVJMJyxcbiAgICBzOiAnc2VydmVyVXJsJ1xufSwge1xuICAgIHE6ICdzZXJ2ZXJVcmwnLFxuICAgIHM6ICdzZXJ2ZXJVcmwnXG59LCB7XG4gICAgcTogJ2Zvcm0nLFxuICAgIHM6ICd4Zm9ybVVybCdcbn0sIHtcbiAgICBxOiAnaWQnLFxuICAgIHM6ICd4Zm9ybUlkJ1xufSwge1xuICAgIHE6ICdpbnN0YW5jZUlkJyxcbiAgICBzOiAnaW5zdGFuY2VJZCdcbn0sIHtcbiAgICBxOiAnaW5zdGFuY2VfaWQnLFxuICAgIHM6ICdpbnN0YW5jZUlkJ1xufSwge1xuICAgIHE6ICdwYXJlbnRXaW5kb3dPcmlnaW4nLFxuICAgIHM6ICdwYXJlbnRXaW5kb3dPcmlnaW4nXG59IF07XG5cbi8vIHJlbmFtZSBxdWVyeSBzdHJpbmcgcGFyYW1ldGVycyB0byBzZXR0aW5ncywgYnV0IG9ubHkgaWYgdGhleSBkbyBub3QgZXhpc3QgYWxyZWFkeVxuc2V0dGluZ3NNYXAuZm9yRWFjaCggZnVuY3Rpb24oIG9iaiApIHtcbiAgICBpZiAoIHR5cGVvZiBxdWVyeVBhcmFtc1sgb2JqLnEgXSAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHNldHRpbmdzWyBvYmoucyBdID09PSAndW5kZWZpbmVkJyApIHtcbiAgICAgICAgc2V0dGluZ3NbIG9iai5zIF0gPSBxdWVyeVBhcmFtc1sgb2JqLnEgXTtcbiAgICB9XG59ICk7XG5cbi8vYWRkIGRlZmF1bHQgbG9naW4gVXJsXG5zZXR0aW5ncy5sb2dpblVybCA9IGNvbmZpZ1sgJ2Jhc2VQYXRoJyBdICsgREVGQVVMVF9MT0dJTl9VUkw7XG5cbi8vIGFkZCBkZWZhdWx0IHJldHVybiBVcmxcbnNldHRpbmdzLmRlZmF1bHRSZXR1cm5VcmwgPSBjb25maWdbICdiYXNlUGF0aCcgXSArIERFRkFVTFRfVEhBTktTX1VSTDtcblxuLy8gYWRkIGRlZmF1bHRzIG9iamVjdFxuc2V0dGluZ3MuZGVmYXVsdHMgPSB7fTtcbmZvciAoIHZhciBwIGluIHF1ZXJ5UGFyYW1zICkge1xuICAgIGlmICggcXVlcnlQYXJhbXMuaGFzT3duUHJvcGVydHkoIHAgKSApIHtcbiAgICAgICAgdmFyIHBhdGg7XG4gICAgICAgIHZhciB2YWx1ZTtcbiAgICAgICAgaWYgKCBwLnNlYXJjaCggL2RcXFsoLiopXFxdLyApICE9PSAtMSApIHtcbiAgICAgICAgICAgIHBhdGggPSBkZWNvZGVVUklDb21wb25lbnQoIHAubWF0Y2goIC9kXFxbKC4qKVxcXS8gKVsgMSBdICk7XG4gICAgICAgICAgICB2YWx1ZSA9IGRlY29kZVVSSUNvbXBvbmVudCggcXVlcnlQYXJhbXNbIHAgXSApO1xuICAgICAgICAgICAgc2V0dGluZ3MuZGVmYXVsdHNbIHBhdGggXSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgfVxufVxuXG4vLyBhZGQgY29tbW9uIGFwcCBjb25maWd1cmF0aW9uIGNvbnN0YW50c1xuZm9yICggdmFyIHByb3AgaW4gY29uZmlnICkge1xuICAgIGlmICggY29uZmlnLmhhc093blByb3BlcnR5KCBwcm9wICkgKSB7XG4gICAgICAgIHNldHRpbmdzWyBwcm9wIF0gPSBjb25maWdbIHByb3AgXTtcbiAgICB9XG59XG5cbi8vIGFkZCBzdWJtaXNzaW9uIHBhcmFtZXRlciB2YWx1ZVxuaWYgKCBzZXR0aW5ncy5zdWJtaXNzaW9uUGFyYW1ldGVyICYmIHNldHRpbmdzLnN1Ym1pc3Npb25QYXJhbWV0ZXIubmFtZSApIHtcbiAgICAvLyBzZXRzIHRvIHVuZGVmaW5lZCB3aGVuIG5lY2Vzc2FyeVxuICAgIHNldHRpbmdzLnN1Ym1pc3Npb25QYXJhbWV0ZXIudmFsdWUgPSBxdWVyeVBhcmFtc1sgc2V0dGluZ3Muc3VibWlzc2lvblBhcmFtZXRlci5uYW1lIF07XG59XG5cbi8vIHNldCBkZWZhdWx0IG1heFN1Ym1pc3Npb25TaXplXG5zZXR0aW5ncy5tYXhTaXplID0gREVGQVVMVF9NQVhfU0laRTtcblxuLy8gYWRkIHR5cGVcbmlmICggd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLmluZGV4T2YoICcvcHJldmlldycgKSA9PT0gMCApIHtcbiAgICBzZXR0aW5ncy50eXBlID0gJ3ByZXZpZXcnO1xufSBlbHNlIGlmICggd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLmluZGV4T2YoICcvc2luZ2xlJyApID09PSAwICkge1xuICAgIHNldHRpbmdzLnR5cGUgPSAnc2luZ2xlJztcbn0gZWxzZSBpZiAoIHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5pbmRleE9mKCAnL2VkaXQnICkgPT09IDAgKSB7XG4gICAgc2V0dGluZ3MudHlwZSA9ICdlZGl0Jztcbn0gZWxzZSBpZiAoIHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5pbmRleE9mKCAnL3ZpZXcnICkgPT09IDAgKSB7XG4gICAgc2V0dGluZ3MudHlwZSA9ICd2aWV3Jztcbn0gZWxzZSB7XG4gICAgc2V0dGluZ3MudHlwZSA9ICdvdGhlcic7XG59XG5cbi8vIFByb3ZpZGUgZWFzeSB3YXkgdG8gY2hhbmdlIG9ubGluZS1vbmx5IHByZWZpeCBpZiB3ZSB3YW50ZWQgdG8gaW4gdGhlIGZ1dHVyZVxuc2V0dGluZ3MuZW5rZXRvSWRQcmVmaXggPSAnOjonO1xuXG4vLyBEZXRlcm1pbmUgd2hldGhlciB2aWV3IGlzIG9mZmxpbmUtY2FwYWJsZVxuc2V0dGluZ3Mub2ZmbGluZSA9ICEhZG9jdW1lbnQucXVlcnlTZWxlY3RvciggJ2h0bWwnICkuZ2V0QXR0cmlidXRlKCAnbWFuaWZlc3QnICk7XG5cbi8vIEV4dHJhY3QgRW5rZXRvIElEXG5zZXR0aW5ncy5lbmtldG9JZCA9ICggc2V0dGluZ3Mub2ZmbGluZSApID8gX2dldEVua2V0b0lkKCAnIycsIHdpbmRvdy5sb2NhdGlvbi5oYXNoICkgOiBfZ2V0RW5rZXRvSWQoICdcXC8nICsgc2V0dGluZ3MuZW5rZXRvSWRQcmVmaXgsIHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSApO1xuXG4vLyBTZXQgbXVsdGlwbGVBbGxvd2VkIGZvciBzaW5nbGUgd2ViZm9ybSB2aWV3c1xuaWYgKCBzZXR0aW5ncy50eXBlID09PSAnc2luZ2xlJyAmJiBzZXR0aW5ncy5lbmtldG9JZC5sZW5ndGggIT09IDMyICYmIHNldHRpbmdzLmVua2V0b0lkLmxlbmd0aCAhPT0gNjQgKSB7XG4gICAgc2V0dGluZ3MubXVsdGlwbGVBbGxvd2VkID0gdHJ1ZTtcbn1cblxuLy8gRGV0ZXJtaW5lIHdoZXRoZXIgXCJnbyB0b1wiIGZ1bmN0aW9uYWxpdHkgc2hvdWxkIGJlIGVuYWJsZWQuXG5zZXR0aW5ncy5nb1RvID0gc2V0dGluZ3MudHlwZSA9PT0gJ2VkaXQnIHx8IHNldHRpbmdzLnR5cGUgPT09ICdwcmV2aWV3JyB8fCBzZXR0aW5ncy50eXBlID09PSAndmlldyc7XG5cbi8vIEEgYml0IGNydWRlIGFuZCBoYWNrYWJsZSBieSB1c2VycywgYnV0IHRoaXMgd2F5IGFsc28gdHlwZT12aWV3IHdpdGggYSByZWNvcmQgd2lsbCBiZSBjYXVnaHQuXG5zZXR0aW5ncy5wcmludFJlbGV2YW50T25seSA9ICEhc2V0dGluZ3MuaW5zdGFuY2VJZDtcblxuZnVuY3Rpb24gX2dldEVua2V0b0lkKCBwcmVmaXgsIGhheXN0YWNrICkge1xuICAgIHZhciBpZCA9IG5ldyBSZWdFeHAoIHByZWZpeCApLnRlc3QoIGhheXN0YWNrICkgPyBoYXlzdGFjay5zdWJzdHJpbmcoIGhheXN0YWNrLmxhc3RJbmRleE9mKCBwcmVmaXggKSArIHByZWZpeC5sZW5ndGggKSA6IG51bGw7XG4gICAgcmV0dXJuIGlkO1xufVxuXG5mdW5jdGlvbiBfZ2V0QWxsUXVlcnlQYXJhbXMoKSB7XG4gICAgdmFyIHZhbDtcbiAgICB2YXIgcHJvY2Vzc2VkVmFsO1xuICAgIHZhciBxdWVyeSA9IHdpbmRvdy5sb2NhdGlvbi5zZWFyY2guc3Vic3RyaW5nKCAxICk7XG4gICAgdmFyIHZhcnMgPSBxdWVyeS5zcGxpdCggJyYnICk7XG4gICAgdmFyIHBhcmFtcyA9IHt9O1xuXG4gICAgZm9yICggdmFyIGkgPSAwOyBpIDwgdmFycy5sZW5ndGg7IGkrKyApIHtcbiAgICAgICAgdmFyIHBhaXIgPSB2YXJzWyBpIF0uc3BsaXQoICc9JyApO1xuICAgICAgICBpZiAoIHBhaXJbIDAgXS5sZW5ndGggPiAwICkge1xuICAgICAgICAgICAgdmFsID0gZGVjb2RlVVJJQ29tcG9uZW50KCBwYWlyWyAxIF0gKTtcbiAgICAgICAgICAgIHByb2Nlc3NlZFZhbCA9ICggdmFsID09PSAndHJ1ZScgKSA/IHRydWUgOiAoIHZhbCA9PT0gJ2ZhbHNlJyApID8gZmFsc2UgOiB2YWw7XG4gICAgICAgICAgICBwYXJhbXNbIHBhaXJbIDAgXSBdID0gcHJvY2Vzc2VkVmFsO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHBhcmFtcztcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBzZXR0aW5ncztcbiIsIm1vZHVsZS5leHBvcnRzPXtcImdvb2dsZUFwaUtleVwiOlwiXCIsXCJtYXBzXCI6W3tcIm5hbWVcIjpcInN0cmVldHNcIixcInRpbGVzXCI6W1wiaHR0cHM6Ly97c30udGlsZS5vcGVuc3RyZWV0bWFwLm9yZy97en0ve3h9L3t5fS5wbmdcIl0sXCJhdHRyaWJ1dGlvblwiOlwiwqkgPGEgaHJlZj1cXFwiaHR0cDovL29wZW5zdHJlZXRtYXAub3JnXFxcIj5PcGVuU3RyZWV0TWFwPC9hPiB8IDxhIGhyZWY9XFxcInd3dy5vcGVuc3RyZWV0bWFwLm9yZy9jb3B5cmlnaHRcXFwiPlRlcm1zPC9hPlwifV0sXCJtb2Rlcm5Ccm93c2Vyc1VSTFwiOlwibW9kZXJuLWJyb3dzZXJzXCIsXCJzdXBwb3J0RW1haWxcIjpcInN1cHBvcnRAa29ib3Rvb2xib3gub3JnXCIsXCJ0aGVtZXNTdXBwb3J0ZWRcIjpbXCJmb3JtaHViXCIsXCJncmlkXCIsXCJrb2JvXCIsXCJwbGFpblwiXSxcImxhbmd1YWdlc1N1cHBvcnRlZFwiOltcImFyXCIsXCJjc1wiLFwiZGVcIixcImVsXCIsXCJlblwiLFwiZXNcIixcImZhXCIsXCJmaVwiLFwiZnJcIixcImhpXCIsXCJpdFwiLFwibG9cIixcIm5sXCIsXCJub1wiLFwicm9cIixcInNrXCIsXCJzdlwiLFwic3dcIixcInZpXCIsXCJ6aFwiXSxcInRpbWVvdXRcIjozMDAwMDAsXCJzdWJtaXNzaW9uUGFyYW1ldGVyXCI6e1wibmFtZVwiOlwiXCJ9LFwiYmFzZVBhdGhcIjpcIlwiLFwicmVwZWF0T3JkaW5hbHNcIjpmYWxzZSxcInZhbGlkYXRlQ29udGludW91c2x5XCI6ZmFsc2UsXCJ2YWxpZGF0ZVBhZ2VcIjp0cnVlfSJdfQ==
